﻿using Raylib_CSharp.Colors;
using Raylib_CSharp.Interact;
using Raylib_CSharp.Rendering;
using Raylib_CSharp.Windowing;
using Raylib_CSharp.Collision;
using Raylib_CSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;


namespace Plants;


internal class Rendering
{
    public static void Init()
    {
        const int screenWidth = 200;
        const int screenHeight = 400;
        const float pointRadius = 10.0f;

        Window.Init(screenWidth, screenHeight, "Hello World");
        Raylib.SetConfigFlags(ConfigFlags.Msaa4XHint);

        Vector2 startPoint = new Vector2(30, 30);
        Vector2 endPoint = new Vector2(screenWidth - 30, screenHeight - 30);

        bool moveStartPoint = false;
        bool moveEndPoint = false;

        while (true)
		{
			if(Window.ShouldClose())
			{
				Window.SetState(ConfigFlags.HiddenWindow);
			}

            Vector2 mouse = MouseHelper.GetMousePosition();

            if (ShapeHelper.CheckCollisionPointCircle(mouse, startPoint, pointRadius) && Input.IsMouseButtonDown(MouseButton.Left)) moveStartPoint = true;
            else if (ShapeHelper.CheckCollisionPointCircle(mouse, endPoint, pointRadius) && Input.IsMouseButtonDown(MouseButton.Left)) moveEndPoint = true;

            if (moveStartPoint)
            {
                startPoint = mouse;
                if (Input.IsMouseButtonReleased(MouseButton.Left)) moveStartPoint = false;
            }

            if (moveEndPoint)
            {
                endPoint = mouse;
                if (Input.IsMouseButtonReleased(MouseButton.Left)) moveEndPoint = false;
            }

            Graphics.BeginDrawing();
			Graphics.ClearBackground(Color.White);

            //Graphics.DrawText("Hello, world!", 12, 12, 20, Color.Black);

            Graphics.DrawLineBezier(startPoint, endPoint, 4.0f, Color.Black);

            Graphics.DrawCircleV(startPoint, ShapeHelper.CheckCollisionPointCircle(mouse, startPoint, 10.0f) ? 14.0f : 8.0f, moveStartPoint ? Color.Red : Color.Black);
            Graphics.DrawCircleV(endPoint, ShapeHelper.CheckCollisionPointCircle(mouse, endPoint, 10.0f) ? 14.0f : 8.0f, moveEndPoint ? Color.Red : Color.Black);


            Graphics.EndDrawing();
		}
	}
}
